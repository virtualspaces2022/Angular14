import { SimpleChanges, ViewEncapsulation } from '@angular/core';
import { Component,OnInit,Input,Output,EventEmitter,ChangeDetectionStrategy,
  OnChanges,OnDestroy,DoCheck,AfterViewChecked,
  AfterContentChecked,AfterViewInit,
  AfterContentInit, 
   } from '@angular/core';
import { Stock } from 'src/app/model/stock';
  //
@Component({
  selector: 'app-stock-item',
  templateUrl: './stock-item.component.html', 
  styleUrls: ['./stock-item.component.css'],
  encapsulation : ViewEncapsulation.None, 
  changeDetection : ChangeDetectionStrategy.OnPush
})//follow to global css
export class StockItemComponent implements OnInit,OnChanges,
OnDestroy,DoCheck,AfterViewChecked,
AfterContentChecked,AfterViewInit,
AfterContentInit
 {
@Input() public stock!:Stock;  // public stocks!:Array<Stock>;
@Output() public toggleFavorite!:EventEmitter<Stock>;
//public stockStyles!:any;

  constructor(){
    this.toggleFavorite=new EventEmitter<Stock>();
  }
  ngOnChanges(changes: SimpleChanges): void {
    throw new Error('Method not implemented.');
  }

  ngOnInit()  {
   // console.log('Stock Item Component - On Init'); 
   /* this.stocks=[
    new Stock('Test stock','TC',80,850),
    new Stock('Test stock 2','TC2',90,50),
    new Stock('Test stock 3','TC3',70,76)
    ];*/
   // let diff=(this.stock.price/this.stock.previousPrice)-1;
    //let largeChange=Math.abs(diff)>0.01;

   /* this.stockClasses={
      "postive":this.stock.isPositiveChange(),
      "negative":!this.stock.isPositiveChange(),
      "large-change":largeChange,
      "small-change":!largeChange
    };
    this.stockStyles={
        "color":this.stock.isPositiveChange()?"green":"red",
        "font-size":largeChange? "1.2em":"0.8em"
    };*/
  }

  onToggleFavorite(event:any){ //,index:any
   // console.log('toggle button for favourite');
   // this.stocks[index].favorite=!this.stocks[index].favorite;
   //this.stock.favorite=!this.stock.favorite;;
   this.toggleFavorite.emit(this.stock);
  }
  trackStockByCode(index:any,stock:Stock){
    console.log("Track Code"+stock.code);
    return stock.code;
  }

  changeStockPrice(){
    this.stock.price+=5;
  }
 
    
    ngAfterViewInit(): void { 
    
    //console.log('Stock Item Component - After View Init'); 
    
    } 
    
    ngAfterViewChecked(): void { 
    
   // console.log('Stock Item Component - After View Checked'); 
    
    } 
    
    ngAfterContentInit(): void { 
    
    //console.log('Stock Item Component - After Content Init'); 
    
    } 
    
    ngAfterContentChecked(): void { 
    
    //console.log('Stock Item Component - After Content Checked'); 
    
    } 
    
    ngDoCheck(): void { 
    
    //console.log('Stock Item Component - Do Check'); 
    
    } 
    
    ngOnDestroy(): void { 
    
    //console.log('Stock Item Component - On Destroy'); 
    
    } 
    
   // ngOnChanges(changes: SimpleChanges): void { 
    
  //  console.log('Stock Item Component - On Changes - ', changes); 
    
   // } 


}
