import { Component,OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators,FormBuilder, FormArray } from '@angular/forms';
import { Stock } from 'src/app/model/stock';
import { MessageService } from 'src/app/services/message.service';
import { StockService } from 'src/app/services/stock.service';

@Component({
  selector: 'app-create-stock',
  templateUrl: './create-stock.component.html',
  styleUrls: ['./create-stock.component.css'],
  providers:[MessageService]
})

export class CreateStockComponent {
  public stock!:Stock;
  public confirmed:boolean=false;
 // public message =null;
  //public nameControl=new FormControl();
  public exchanges=['NYSE','NASDAQ','KLSE','OTHER'];
  public stockForm!:FormGroup;
  public counter=1;
  /* ({ name:new FormControl(null, Validators.required),
    code:new FormControl(null, [Validators.required,Validators.minLength(2)]),
    price:new FormControl(0, [Validators.required,Validators.min(0)])
  })

  constructor(private fb:FormBuilder){ 
    this.createForm();
    this.stock=new Stock('Test Initial'+ this.counter++,'TST',29,90,'NASDAQ');
  }*/
constructor(private stockService: StockService,
    public messageService: MessageService) {
    this.stock =  new Stock('', '', 0, 0, 'NASDAQ');
    this.messageService.Message = 'Component Level: Hello Message Service';
}
/*
  createForm(){
    this.stockForm=this.fb.group({
      name:[null, Validators.required],
      code:[null, [Validators.required,Validators.minLength(2)]],
      price:[0, [Validators.required,Validators.min(0)]],
      notablePeople:this.fb.array([])
    });
  }
  get notablePeople():FormArray{
   return this.stockForm.get('notablePeople') as FormArray; 
  }
  addNotablePerson(){
    this.notablePeople.push(this.fb.group({
      name: ['',Validators.required],
      title:['',Validators.required]
    }))
  }
  removeNotablePerson(index:any){
    this.notablePeople.removeAt(index)
  }
*/
  setStockPrice(price:any){
    this.stock.price=price;
    this.stock.previousPrice=price;
  }
  createStock(stockForm:any){
         /* console.log('StockForm  ',stockForm.value);
          if(stockForm.valid){
            this.stock=stockForm.value.stock;
              //console.log('Creating stock',this.stock);
          }else{
            console.error('invalid record stock',this.stock);
          }*/
          if(stockForm.valid){
            let created=this.stockService.createStock(this.stock);
            if(created){
              this.messageService.Message!="Success created code"+this.stock.code;
              this.stock=new Stock('','',0,0,'nasdaq');
            }else{
              this.messageService.Message!="Fail to create "+this.stock.code+'already existed';
            //  this.message! 
             // = 'Stock with stock code: ' + this.stock.code + ' already exists';
            }
          }else{
            console.error('Stock form has invalid state');
          }
  }
  onSubmit() {
    this.stock=Object.assign({},this.stockForm.value);
    console.log('StockForm Value  ',this.stock);
  }
   resetForm(){
    this.stockForm.reset();
   }
  loadStockFromserver(){
    this.stock=new Stock('Test'+this.counter++,'TSTPTF',100,110,'NASDAQ');
    let stockFormModel=Object.assign({},this.stock);
   // delete stockFormModel.previousPrice;
    //delete stockFormModel.favorite;
    this.stockForm.setValue(stockFormModel);
  }
patchStock(){
this.stock=new Stock('Test Patch'+this.counter++,'TTT',0,0,'KLSE');
this.stockForm.patchValue(this.stock);
}

}
