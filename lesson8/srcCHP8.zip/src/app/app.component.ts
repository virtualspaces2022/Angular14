import { Component, OnInit,
OnChanges,OnDestroy,DoCheck,AfterViewChecked,
AfterContentChecked,AfterViewInit,
AfterContentInit, 
SimpleChanges} from '@angular/core';
import { Stock } from './model/stock';
import { MessageService } from './services/message.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit,
OnChanges,OnDestroy,DoCheck,AfterViewChecked,
AfterContentChecked,AfterViewInit,
AfterContentInit {
  title = 'stock market';
  public stockObj!:Stock;
  private counter:number=1;
  
testMethod(){
  console.log('Test method in App Component Trigger');
}
constructor(public messageService:MessageService){

}

  ngOnInit(): void {
    this.messageService.Message="Hello message service!";
   // this.stockObj=  new Stock('Test stock','TC',80,850,'NASDAQ');
   // console.log('App Component - On Init');
  }
  onToggleFavorite(stock:Stock){ //,index:any
    //console.log('toggle button for favourite', stock);
    // this.stocks[index].favorite=!this.stocks[index].favorite;
    this.stockObj.favorite=!this.stockObj.favorite;;
   
   }
   changeStockObject(){
    this.stockObj=new Stock('Test stock'+this.counter,'TC',80,850,'NASDAQ');
   }
   changeStockPrice(){
    this.stockObj.price+=10;

   }
 

   ngAfterViewInit(): void { 

   // console.log('App Component - After View Init'); 
    
    } 
    
    ngAfterViewChecked(): void { 
    
    //console.log('App Component - After View Checked'); 
    
    } 
    
    ngAfterContentInit(): void { 
    
   // console.log('App Component - After Content Init'); 
    
    } 
    
    ngAfterContentChecked(): void { 
    
    //console.log('App Component - After Content Checked'); 
    
    } 
    
    ngDoCheck(): void { 
    
    //console.log('App Component - Do Check'); 
    
    } 
    
    ngOnDestroy(): void { 
    
    //console.log('App Component - On Destroy'); 
    
    } 
    
    ngOnChanges(changes: SimpleChanges): void { 
    
    //console.log('App Component - On Changes - ', changes); 
    
    } 

}
