export class Stock {
    
 
  public favorite:boolean=false;
  public notablePeople!: Person[];

  constructor(
    public name:string,
    public code: string,
    public price: number,
    public previousPrice:number,
    public exchange:string
  ){}

  isPositiveChange():boolean{
    return this.price>=this.previousPrice;
  }

 /* ngOnInit()  {
    this.name='Test stock';
    this.code='TSC';
    this.price=85;
    this.previousPrice=100;
    this.positiveChange=this.price>=this.previousPrice;
    this.favorite=false;
  }

  toggleFavorite(){
    console.log('toggle button for favourite');
    this.favorite=!this.favorite;
  }*/
}

export class Person{
 public name!:string;
  public title! :string
}
